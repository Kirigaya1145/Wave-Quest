using TreeEditor;
using UnityEngine;
using UnityEngine.UI;

public class FrequencyChallenge : MonoBehaviour
{
    public WaveAnimator targetWave;
    public WaveAnimator playerWave;

    public Slider frekuensiSlider;
    public Button btnCheck;
    public TMPro.TextMeshProUGUI textKecepatan;
    public GameObject panel;
    public GameObject rewardPanel;
    public GameObject retryPanel;
    public PlayerMovement player;

    public float tolerance = 0.15f;
    private bool solved = false;
    void Start()
    {
        frekuensiSlider.value = playerWave.kecepatan;
        frekuensiSlider.onValueChanged.AddListener(OnSliderChange);
        btnCheck.onClick.AddListener(CheckAnswer);
        panel.SetActive(false);
    }
    public void OpenPanel()
    {
        panel.SetActive(true);
        player.SetInputLocked(true);
        solved = false;
        frekuensiSlider.value = playerWave.kecepatan;
        textKecepatan.text = playerWave.kecepatan.ToString("F1");
    }

    public void ClosePanel()
    {
        CancelInvoke(nameof(ClosePanel));
        panel.SetActive(false);
        player.SetInputLocked(false);
        rewardPanel.SetActive(false);
        retryPanel.SetActive(false);
    }
    void OnSliderChange(float value)
    {
        playerWave.kecepatan = value;
        textKecepatan.text = value.ToString("F1");
    }
    void CheckAnswer()
    {
        if (solved) return;
        float error = Mathf.Abs(playerWave.kecepatan - targetWave.kecepatan) / targetWave.kecepatan;
        if (error < tolerance)
        {
            solved = true;
            rewardPanel.SetActive(true);
            Level2Manager.Instance.TandaSelesai("Frekuensi");
            Invoke(nameof(ClosePanel), 1.5f);
        }
        else
        {
            retryPanel.SetActive(true) ;
        }
    }
}
