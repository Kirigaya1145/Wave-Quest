using UnityEngine;
using UnityEngine.SceneManagement;

public class Level2Manager : MonoBehaviour
{
    public static Level2Manager Instance;

    //Waktu Timer 5 detik
    public float totalTimer = 300f;
    private float sisaWaktu;
    private bool timerUp = false;

    //Progression Sub Level
    public bool amplitudoDone = false;
    public bool frekuensiDone = false;
    public bool panjangDone = false;
    public bool AllDone => amplitudoDone && frekuensiDone && panjangDone;

    public TMPro.TMP_Text timerText;
    public string sceneLevel3 = "";
    public string sceneFail = "";

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        sisaWaktu = totalTimer;
    }
    void OnEnable()
    {
        SceneManager.sceneLoaded += CariTimerText;
    }
    void OnDisable()
    {
        SceneManager.sceneLoaded -= CariTimerText;    
    }
    void CariTimerText(Scene scene, LoadSceneMode mode)
    {
        GameObject obj = GameObject.Find("Timer Text");
        if (obj != null)
        {
            timerText = obj.GetComponent<TMPro.TMP_Text>();
        } 
        else
        {
            timerText = null;
        }
    }
    void Update()
    {
        if (timerUp) return;
        sisaWaktu -= Time.deltaTime;
        if (timerText != null)
        {
            int menit = Mathf.Max(0, Mathf.FloorToInt(sisaWaktu / 60f));
            int detik = Mathf.Max(0, Mathf.FloorToInt(sisaWaktu % 60f));
            timerText.text = menit.ToString("00") + ":" + detik.ToString("00");
        }
        if (sisaWaktu <= 0f)
        {
            timerUp = true;
            Debug.Log("Waktu Level 2 habis");
        }
    }
    public void TandaSelesai(string jenis)
    {
        if (jenis == "Amplitudo") amplitudoDone = true;
        if (jenis == "Frekuensi") frekuensiDone = true;
        if (jenis == "Panjang") panjangDone = true;
        if (AllDone)
        {
            Debug.Log("Level 2 selesai");
        }
    }
}
