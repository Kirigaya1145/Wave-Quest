using TMPro;
using TreeEditor;
using UnityEngine;
using UnityEngine.UI;

public class PanjangGelombangChallenge : MonoBehaviour
{
    public WaveAnimator targetWave;
    public WaveAnimator playerWave;
    public Slider kerapatanSlider;

    public TextMeshProUGUI kerapatanText;
    public Button btnCheck;
    public GameObject panel;
    public GameObject rewardPanel;
    public GameObject retryPanel;
    public PlayerMovement player;

    public float tolerance = 0.15f;
    private bool solved = false;
    
    void Start()
    {
        kerapatanSlider.value = playerWave.kerapatan;
        kerapatanSlider.onValueChanged.AddListener(OnSliderChange);
        btnCheck.onClick.AddListener(CheckAnswer);
        panel.SetActive(false);
    }
    public void OpenPanel()
    {
        panel.SetActive(true);
        player.SetInputLocked(true);
        solved = false;
        kerapatanSlider.value = playerWave.kerapatan;
        kerapatanText.text = playerWave.kerapatan.ToString("F1");
    }

    public void ClosePanel()
    {
        CancelInvoke(nameof(ClosePanel));
        panel.SetActive(false);
        player.SetInputLocked(false);
        rewardPanel.SetActive(false);
        retryPanel.SetActive(false);
    }
    void OnSliderChange(float value)
    {
        playerWave.kerapatan = value;
        kerapatanText.text = value.ToString("F1");
    }
    void CheckAnswer()
    {
        if (solved) return;
        float error = Mathf.Abs(playerWave.kerapatan - targetWave.kerapatan) / targetWave.kerapatan;
        if (error < tolerance)
        {
            solved = true;
            rewardPanel.SetActive(true);
            Level2Manager.Instance.TandaSelesai("Panjang");
            Invoke(nameof(ClosePanel), 1.5f);
        }
        else
        {
            retryPanel.SetActive(true);
        }
    }
}
